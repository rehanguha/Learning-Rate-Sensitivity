from tensorflow import keras
from tensorflow.keras import datasets
import matplotlib.pylab as plt
import numpy as np
import json
import pandas as pd
from tensorflow.keras.optimizers import SGD, RMSprop, Adam, Adagrad, Adadelta, Adamax, Nadam
import alert

mail = alert.mail(sender_email="rehan.logs@gmail.com", sender_password="rehanguhalogs")


lrs = np.linspace(0.001, 0.1, num = 100, endpoint =True).tolist()
epochs =[200] 
optimizers = [SGD, RMSprop, Adam, Adagrad, Adadelta, Adamax, Nadam]


(x_train, y_train), (x_test, y_test) = datasets.mnist.load_data()

y_train = keras.utils.to_categorical(y_train, 10)
y_test = keras.utils.to_categorical(y_test, 10)

x_train = keras.utils.normalize(x_train, axis=1)
x_test = keras.utils.normalize(x_test, axis=1)

# Reserve 10,000 samples for validation
x_val = x_train[-10000:]
y_val = y_train[-10000:]
x_train = x_train[:-10000]
y_train = y_train[:-10000]


def compile_optimizer(optimizer):
    model = keras.Sequential([
        keras.layers.Flatten(input_shape=x_train[0].shape),
        keras.layers.Dense(64, activation='relu'),
        keras.layers.Dense(64, activation='relu'),
        keras.layers.Dense(10, activation='softmax')
    ])
    model.compile(
        optimizer=optimizer,
        loss=keras.losses.categorical_crossentropy,
        metrics=['accuracy'])

    return model


def train_mnist(model, epoch):
    history = model.fit(x_train, y_train,
                    batch_size=64,
                    epochs=epoch,
                    verbose=True,
                    shuffle=True,
                    validation_data=(x_val, y_val))

    return history, model


mnist_df = pd.DataFrame(columns = ['opimizer', 'lr', 'epoch', 'accuracy', 'loss', 'test_accuracy', 'test_loss'])


for opt in optimizers:
    for lr in lrs:
        for epoch in epochs:
            model = compile_optimizer(opt(learning_rate=lr))
            history, model = train_mnist(model, epoch)
            train_loss, train_accuracy = model.evaluate(x_train, y_train, verbose=False)
            test_loss, test_accuracy = model.evaluate(x_test, y_test, verbose=False)
            mnist_df = mnist_df.append(
            {
              'opimizer': opt.__name__,
              'lr': lr,
              'epoch': epoch,
              'accuracy': train_accuracy,
              'loss': train_loss,
              'test_accuracy': test_accuracy,
              'test_loss': test_loss
            }, ignore_index= True)
    mnist_df.to_csv("output/MNIST_LR.csv")
    mail.send_email(receiver_email="rehan.guha@imaginea.com", subject="{name} Completed".format(name=opt.__name__,lr=lr), msg="Done.")

mnist_df.to_csv("output/MNIST_LR.csv")
    
mail.send_email(receiver_email="rehan.guha@imaginea.com", subject="All Completed".format(name=opt.__name__,lr=lr), msg="Saved.")



